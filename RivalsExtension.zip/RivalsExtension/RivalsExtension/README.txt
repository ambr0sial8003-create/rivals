RYUMA PRIVATE — Visual Studio 2.0

INSTALLATION
1. Décompresser le ZIP.
2. Ouvrir chrome://extensions ou edge://extensions.
3. Activer le mode développeur puis Charger l’extension non empaquetée.
4. Sélectionner le dossier ryuma-private-extension.
5. Cliquer sur l’icône de l’extension pour ouvrir le studio.

FONCTIONS REELLES
- Trois captures originales fournies par le créateur.
- Ajustements locaux saturation / contraste / luminosité / teinte.
- Import de captures PNG, JPG ou WEBP (max 20 Mo).
- Export PNG avec filtres réellement appliqués.
- Enregistrement local des profils de réglages et export JSON.
- Suivi local de quêtes et de stats manuelles.

LIMITES
L’extension ne charge pas de shaders dans le client Roblox, ne débloque pas de skins et n’automatise pas les quêtes du jeu. Aucun droit sensible Chrome demandé. Fan-made, sans affiliation à Roblox/RIVALS.
