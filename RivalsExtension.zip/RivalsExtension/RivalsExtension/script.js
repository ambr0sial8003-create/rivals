const presets=[{id:'night',name:"Ryuma's Nightfall",desc:'Neon Blue · Dark PvP',image:'assets/ryuma-night.png',values:[118,120,91,0]},{id:'sunset',name:"Ryuma's Sunset",desc:'Pastel Sky · Warm PvP',image:'assets/ryuma-sunset.png',values:[120,108,105,0]},{id:'golden',name:"Ryuma's GoldRush",desc:'Golden Glow · Crystal PvP',image:'assets/ryuma-golden.png',values:[128,114,106,0]}];
const $=x=>document.getElementById(x), keys=['saturation','contrast','brightness','hue'];let current='sunset',original=false,customImageUrl=null;
const read=(key,fallback)=>{try{let v=localStorage.getItem('ryuma-'+key);return v===null?fallback:JSON.parse(v)}catch{return fallback}};
const write=(key,v)=>localStorage.setItem('ryuma-'+key,JSON.stringify(v));
function flash(s){$('toast').textContent=s;$('toast').style.display='block';clearTimeout(window.flashTimeout);window.flashTimeout=setTimeout(()=>$('toast').style.display='none',2400)}
function renderCards(){$('shaderCards').innerHTML=presets.map(p=>`<article class="shader-card ${current===p.id?'selected':''}"><img src="${p.image}" alt="Capture RIVALS ${p.name}"><div class="card-content"><span class="chip">PRESET</span><h3>${p.name}</h3><p>${p.desc}</p><button class="${current===p.id?'btn-primary':'btn-outline'}" data-preset="${p.id}">${current===p.id?'✓ Selected':'Preview shader'}</button></div></article>`).join('');document.querySelectorAll('[data-preset]').forEach(b=>b.onclick=()=>choose(b.dataset.preset))}
function choose(id){current=id;original=false;let p=presets.find(x=>x.id===id);$('selectedName').textContent=p.name;if(customImageUrl){URL.revokeObjectURL(customImageUrl);customImageUrl=null}$('previewImage').src=p.image;let vals=read('preset-'+id,p.values);keys.forEach((k,i)=>$(k).value=vals[i]);renderCards();applyFilters()}
function applyFilters(){let v=keys.map(k=>Number($(k).value));$('satOut').textContent=v[0]+'%';$('conOut').textContent=v[1]+'%';$('briOut').textContent=v[2]+'%';$('hueOut').textContent=v[3]+'°';$('previewImage').style.filter=original?'none':`saturate(${v[0]}%) contrast(${v[1]}%) brightness(${v[2]}%) hue-rotate(${v[3]}deg)`;$('previewTag').textContent=original?'ORIGINAL IMAGE':'PREVIEW / FILTERS ON'}
keys.forEach(k=>$(k).addEventListener('input',()=>{original=false;applyFilters()}));$('before').onpointerdown=()=>{original=true;applyFilters()};$('before').onpointerup=$('before').onpointerleave=()=>{original=false;applyFilters()};$('before').onclick=()=>flash('Maintiens le bouton pour voir la capture originale');$('save').onclick=()=>{write('preset-'+current,keys.map(k=>Number($(k).value)));flash('Preset enregistré localement ✓')};
const pages={shaders:['PVP SHADERS','PvP visual studio','Trois profils graphiques basés sur tes captures de jeu.'],skins:['SKIN PREVIEW','Explore the collection.','Prévisualisation de skins — aucun déblocage dans le jeu.'],quests:['QUEST TRACKER','Stay on top of your quests.','Suivi personnel de tes objectifs, sans automatisation du jeu.'],stats:['STATS PRO','Track your progress.','Indicateurs personnels saisis manuellement.'],graphics:['GRAPHICS LAB','Tune your visuals.','Réglages et export de presets pour tes aperçus.']};
document.querySelectorAll('#nav button').forEach(b=>b.onclick=()=>{document.querySelectorAll('#nav button').forEach(n=>n.classList.toggle('active',n===b));document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===b.dataset.page));let t=pages[b.dataset.page];$('crumb').textContent=t[0];$('heading').textContent=t[1];$('intro').textContent=t[2]});
document.querySelectorAll('.previewSkin').forEach(b=>b.onclick=()=>{$('modalImage').src=b.dataset.image;$('modal').hidden=false});$('closeModal').onclick=()=>{$('modal').hidden=true};$('modal').onclick=e=>{if(e.target===$('modal'))$('modal').hidden=true};window.addEventListener('keydown',e=>{if(e.key==='Escape')$('modal').hidden=true});
let quests=read('quests',[]);function renderQuests(){if(!quests.length){$('questList').innerHTML='<p class="hint">Aucune quête. Ajoute ton premier objectif ci-dessus.</p>';return}$('questList').innerHTML=quests.map((q,i)=>`<div class="quest ${q.progress>=q.goal?'done':''}"><div><strong>${escapeHtml(q.name)}</strong><small>${q.progress} / ${q.goal} · ${Math.round(q.progress/q.goal*100)}%</small></div><div class="quest-actions"><button data-inc="${i}" aria-label="Augmenter la progression">+1</button><button data-reset="${i}" aria-label="Réinitialiser">↺</button><button data-delete="${i}" aria-label="Supprimer">✕</button></div></div>`).join('');document.querySelectorAll('[data-inc]').forEach(b=>b.onclick=()=>{let q=quests[+b.dataset.inc];q.progress=Math.min(q.goal,q.progress+1);persistQuests()});document.querySelectorAll('[data-reset]').forEach(b=>b.onclick=()=>{quests[+b.dataset.reset].progress=0;persistQuests()});document.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>{quests.splice(+b.dataset.delete,1);persistQuests()})}function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}function persistQuests(){write('quests',quests);renderQuests()}
$('questForm').onsubmit=e=>{e.preventDefault();let name=$('questName').value.trim(),goal=Number($('questGoal').value);if(!name||goal<1||goal>99999)return;quests.push({name,goal,progress:0});persistQuests();$('questName').value='';flash('Quête ajoutée ✓')};renderQuests();
let stats=read('stats',{wins:0,losses:0,kills:0,deaths:0});function renderStats(){Object.keys(stats).forEach(k=>$(k).value=stats[k]);$('winsVal').textContent=stats.wins;$('lossesVal').textContent=stats.losses;$('rateVal').textContent=(stats.wins+stats.losses?100*stats.wins/(stats.wins+stats.losses):0).toFixed(1)+'%';$('kdVal').textContent=(stats.deaths?stats.kills/stats.deaths:stats.kills).toFixed(2)}$('statsForm').onsubmit=e=>{e.preventDefault();for(let k of Object.keys(stats))stats[k]=Math.max(0,Math.floor(Number($(k).value)||0));write('stats',stats);renderStats();flash('Stats enregistrées ✓')};renderStats();
$('competitive').onclick=()=>{document.querySelector('[data-page="shaders"]').click();choose('sunset');[113,108,104,0].forEach((v,i)=>$(keys[i]).value=v);applyFilters();flash('Preset compétitif appliqué à l’aperçu')};
$('export').onclick=()=>{let data={name:'RYUMA PRIVATE',note:'Presets pour aperçu dans le navigateur uniquement. Ne modifie pas Roblox.',presets:presets.map(p=>({name:p.name,sourceImage:p.image,filters:read('preset-'+p.id,p.values)}))},blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='ryuma-private-presets.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};
choose('sunset');

// Fonctions réelles de traitement d’image : import et export local.
$('customImage').addEventListener('change',e=>{
 const file=e.target.files?.[0]; if(!file)return;
 if(!/^image\/(png|jpeg|webp)$/.test(file.type)){flash('Format non pris en charge');return}
 if(file.size>20*1024*1024){flash('Image trop volumineuse (20 Mo max)');return}
 if(customImageUrl)URL.revokeObjectURL(customImageUrl);
 customImageUrl=URL.createObjectURL(file);
 $('previewImage').src=customImageUrl; original=false;applyFilters();flash('Capture importée');
});
$('resetImage').addEventListener('click',()=>{if(customImageUrl)URL.revokeObjectURL(customImageUrl);customImageUrl=null;$('customImage').value='';$('previewImage').src=presets.find(p=>p.id===current).image;applyFilters();flash('Capture du preset restaurée')});
$('downloadImage').addEventListener('click',async()=>{
 const img=$('previewImage');
 try{
   if(!img.complete || !img.naturalWidth)await img.decode();
   const canvas=document.createElement('canvas');canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;
   const ctx=canvas.getContext('2d');if(!ctx)throw Error('Canvas indisponible');
   const v=keys.map(k=>Number($(k).value));
   ctx.filter=`saturate(${v[0]}%) contrast(${v[1]}%) brightness(${v[2]}%) hue-rotate(${v[3]}deg)`;
   ctx.drawImage(img,0,0);
   canvas.toBlob(blob=>{
      if(!blob){flash('Export impossible');return}
      const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='ryuma-'+current+'-'+Date.now()+'.png';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);flash('Image PNG exportée');
   },'image/png');
 }catch(err){flash('Impossible de traiter cette image')}
});
